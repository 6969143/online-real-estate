$(document).ready(function(){
    $(window).scroll(function(){
        // scroll navbar on scroll script
        if (this.scrollY > 20){
            $('.navbar').addClass("sticky");
            $('.menu-btn').addClass('sticky');
        }else{
            $('.navbar').removeClass("sticky");
            $('.menu-btn').removeClass("sticky");

            $('.navbar').removeClass('active');
            $('.navbar .menu').removeClass('active');
            $('.menu-btn i').removeClass('active');
        }
        
    });

    $('.navbar .menu li a').click(function(){
        // applying again smooth scroll on menu items click
        $('html').css("scrollBehavior", "smooth");
    });

    // toggle menu/navbar script
    $('.menu-btn, .menu li a').click(function(){
        $('.navbar').toggleClass('active');
        $('.navbar .menu').toggleClass('active');
        $('.menu-btn i').toggleClass('active');
    });
});
